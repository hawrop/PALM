% The main program that solves the problem of monitoring with forced dynamics

clear;

% object parameters

% A - matrix of coefficients k_1, k_2, k_3 [1/day]
k_1=0.2;
k_2=0.185;
k_3=0.71;
A=[-k_1 0;-k_2,-k_3];

% measurement matrix
C=[0,1];

% covariance matrix of the measurement disturbances
%  V - Riccati  V1 - object

V=[0.1];
V1=V;

% matrix of interactions of noises signals 

D=[1,0;0,1];

% covariance matrix of the system disturbances
%  W - riccati  W1 - obiekt

W=[6,-4;-4,2]; %[18,-6;-6,9] %[9,-4;-4,6] %[3,-2;-2,1]
W1=W; 

% discretization step
dt=0.1;

% initial values of BOD and DO for each section

WPo1=[70;-10];
WPo2=[70;-10];
WPo3=[70;-10];
WP=[WPo1;WPo2;WPo3];

% object simulation and measurement

[x1,y1,n]=object(WP,dt,W1,V1,A,D,C);

%%%%%%%%%%%%
% determination of the KF gain from the Riccati equation
KFr=riccati(A,C,V,D,W); 
disp(['KFr = [',num2str(KFr(1,1)),';',num2str(KFr(2,1)),']'])

% eigenvalues of the matrix A
wwA=eig(A);
% disp(['eig(A)=[',num2str(wwA(1,1)),',',num2str(wwA(2,1)),']'])

Acl=A-KFr*C;
wwAcl=eig(Acl);
% disp(['eig(Acl)=[',num2str(wwAcl(1,1)),';',num2str(wwAcl(2,1)),']']) 

%%%%%%%%%%%%%

% PALM algorithm parameters

% proportionality parameter of changes in the gain coefficient

kp1=[-0.9;0.17]; %[-0.75;0.13]; %[-0.9;0.17]; %[-0.9;0.2]; %[-0.4;0.08]; %[-1.2;0.3]; 

% parameters defining the boundaries of the eigenvalue location area

tan=0.5;      %0.5=27 0.9=42 0.2=11
eta=-1.5; %-2; %-1; %-1.5;

wo=-1.5;

% initial values of generated signals

xe1=[10;-5]; 
xe2=[10;-5];
 
% initial value of PALM algorithm gain

KFn(:,1)=[0;0]; 
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


sRA=0; sBA=0; sRK=0; sBK=0;
ur=0; uir=0; ur1=0;

for i=1:n
     xe2(:,i+1)=xe2(:,i)+ dt*(A*xe2(:,i)+KFr*(y1(i)-C*xe2(:,i))); % KALMAN    
     xe1(:,i+1)=xe1(:,i)+ dt*(A*xe1(:,i)+KFn(:,i)*(y1(i)-C*xe1(:,i))); % PALM
     
     if(xe1(1,i+1)<0)
         xe1(1,i+1)=0;
     end
     if(xe1(2,i+1)>0)
         xe1(2,i+1)=0;
     end
     
  epe(i)=y1(i)-C*xe1(:,i); % calculation of adaptation error
  
if(i==1)
    depp(i)=0;  
else
  depp(i)=(epe(i)-epe(i-1))/dt;  
end
     
  eRT(i)=x1(2,i)-xe1(2,i); %PALM
  eBZT(i)=x1(1,i)-xe1(1,i);
  
  ekRT(i)=x1(2,i)-xe2(2,i); %Kalman
  ekBZT(i)=x1(1,i)-xe2(1,i);
   
  sRA=sRA+(abs(eRT(i))/x1(2,i))*100;
  sBA=sBA+(abs(eBZT(i))/x1(1,i))*100;
  sRK=sRK+(abs(ekRT(i))/x1(2,i))*100;
  sBK=sBK+(abs(ekBZT(i))/x1(1,i))*100;
  
  Be(i)=(x1(1,i)-xe1(1,i))^2;
  Re(i)=(x1(2,i)-xe1(2,i))^2;
  Bek(i)=(x1(1,i)-xe2(1,i))^2;
  Rek(i)=(x1(2,i)-xe2(2,i))^2;
  
 
  
  AclaA=A-KFn(:,i)*C;
  wwAclaA(i,:)=eig(AclaA); % determination of eigenvalues
       
  DKF=kp1*epe(i);    % calculation of gain correction
    
 % update of gain

if(abs(epe(i))<0.001)
     KFn(:,i+1)= KFn(:,i);
else
  
  if(epe(i)==0)
       if(depp(i)==0)
            KFn(:,i+1)= KFn(:,i);
       end
       if(depp(i)<0)
            KFn(:,i+1)= KFn(:,i)-DKF;
       end
       if(depp(i)>0)
            KFn(:,i+1)= KFn(:,i)+DKF;
       end
  end
  
  if(epe(i)>0)
        if(depp(i)==0)
            KFn(:,i+1)= KFn(:,i)+DKF;
        end     
        if(depp(i)<0)
            KFn(:,i+1)= KFn(:,i);
        end
        if(depp(i)>0)
            KFn(:,i+1)= KFn(:,i)+DKF*wo;
        end
  end
  if(epe(i)<0)
        if(depp(i)==0)
            KFn(:,i+1)= KFn(:,i)-DKF;
        end     
        if(depp(i)<0)
            KFn(:,i+1)= KFn(:,i)-DKF;           
        end
        if(depp(i)>0)
            KFn(:,i+1)= KFn(:,i);            
        end
  end  
end
   if(KFn(1,i+1)>0)
       KFn(1,i+1)=0; 
   end
   if(KFn(2,i+1)<0)
       KFn(2,i+1)=0; 
   end
   
AclaAn=A-KFn(:,i+1)*C;
wwAclaAn(i,:)=eig(AclaAn);

% controls the first hits of eigenvalues in a set area of their location

if(i>2 && ur==0 && imag(wwAclaA(i,2))==0 && real(wwAclaA(i,1))>eta )
    KFsr=KFn(:,i-1);
    %disp(['KFsr(',num2str(i),')= [',num2str(KFsr(1)),';',num2str(KFsr(2)),']'])
    %disp(['wwAclaA(',num2str(i-1),')=[',num2str(wwAclaA(i-1,1)),';',num2str(wwAclaA(i-1,2)),']'])
    ur=1;
end

if(i>2 && uir==0 && abs(imag(wwAclaA(i,2))/real(wwAclaA(i,2)))<tan && real(wwAclaA(i,1))<eta  && imag(wwAclaA(i,2))~=0 )
    KFsir=KFn(:,i);
    %disp(['KFsir(',num2str(i),')= [',num2str(KFsir(1)),';',num2str(KFsir(2)),']'])
    %disp(['wwAclaA(',num2str(i),')=[',num2str(wwAclaA(i,1)),';',num2str(wwAclaA(i,2)),']'])
    uir=1; 
end

% maintaining eigenvalues in a set location
        
if( ur1==1 && imag(wwAclaAn(i,2))~=0)
    if( uir==1 && real(wwAclaAn(i,1))>real(wwAclaA(i,1)))
        KFn(:,i+1)=KFsir;
    else
        KFn(:,i+1)=KFn(:,i+1);
    end   
end

if(i>2 && (uir==1 || ur1==1) && real(wwAclaAn(i,1))>eta && imag(wwAclaAn(i,1))~=0  ) 
    if(uir==1)
        KFn(:,i+1)=KFsir;
    end
    if(ur1==1)
        KFn(:,i+1)=KFn(:,i); 
    end
end    

if(uir==1 && imag(wwAclaAn(i,1))~=0 && abs(imag(wwAclaAn(i,2))/real(wwAclaAn(i,2)))>tan)
    KFn(:,i+1)=KFn(:,i); 
end

if(real(wwAclaAn(i,1))>eta && imag(wwAclaAn(i,1))==0 &&  ur==1)
    if(uir==1)
        KFn(:,i+1)=KFsir;  %KFn(:,i);
    else
        KFn(:,i+1)=KFn(:,i);
    end    
end

AclaAw=A-KFn(:,i)*C;
wwAclaAw(i,:)=eig(AclaAw);

end

wwA_fig(wwA,wwAcl,wwAclaAw,n) % distribution of eigenvalues

%%%%%%

WSBP=(1/n)*(sum(Be));
WSRP=(1/n)*(sum(Re));
WSBK=(1/n)*(sum(Bek));
WSRK=(1/n)*(sum(Rek));
 
MAE_B_P=abs(sBA/n);
MAE_D_P=abs(sRA/n);
MAE_B_K=abs(sBK/n);
MAE_D_K=abs(sRK/n);

RMSE_B_P=sqrt(WSBP);
RMSE_D_P=sqrt(WSRP);
RMSE_B_K=sqrt(WSBK);
RMSE_D_K=sqrt(WSRK);

disp(['RMSE_BOD_PALM = ',num2str(RMSE_B_P)]) % Root Mean Squared Error
disp(['RMSE_DO_PALM = ',num2str(RMSE_D_P)]) 
disp(['RMSE_BOD_KF = ',num2str(RMSE_B_K)]) 
disp(['RMSE_DO_KF = ',num2str(RMSE_D_K)]) 
disp(['MAE_BOD_PALM = ',num2str(MAE_B_P)]) % Mean Absolute Error
disp(['MAE_DO_PALM = ',num2str(MAE_D_P)]) 
disp(['MAE_BOD_KF = ',num2str(MAE_B_K)]) 
disp(['MAE_DO_KF = ',num2str(MAE_D_K)])

%%%%%%%%%%%%%%%%

% saving the results to a .xlsx file

indicators_table = table(MAE_B_P, MAE_D_P, MAE_B_K, MAE_D_K, RMSE_B_P, RMSE_D_P, RMSE_B_K, RMSE_D_K);

path = 'SAVEDATA/experiments.xlsx'; 
if exist(path, 'file') == 0
    writetable(indicators_table, path);
else
    writetable(indicators_table, path, 'WriteMode', 'Append');
end
 
%%%%%%%%%%%%%%%%%

t1=0:dt:n*dt;
t2=0:dt:(n-1)*dt;

figure
subplot(2,1,1); plot(t1,KFn(1,:),'b') 
xlim([0 36])
ylabel('K') 
legend('BOD')
title('Changes in the K coefficients') 
grid
subplot(2,1,2); plot(t1,KFn(2,:),'r')
xlim([0 36])
xlabel('t [day]')
ylabel('K')
legend('DO')
grid
  

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

 figure
 plot(t1,x1(1,:),'b')
 hold on
 plot(t2,y1,':k')
 plot(t1,xe2(1,:),'r')
 plot(t1,xe1(1,:),'k')       
 plot (t1,x1(2,:),'b')          
 plot(t1,xe2(2,:),'r')           
 plot(t1,xe1(2,:),'k')
 xlim([0 36])
 xlabel('t [day]')
 ylabel('DO/BOD [mg/l]')
 legend('object','measur.','KF','PALM')
 grid
 title('Signals generated by the PALM algorithm and Kalman filter')
     

