% RMSE and MAE quality indicators of monitoring of BOD and DO signals 
% generated with the PALM algorithm

clear;

data=dir('DATA');
data=data(3:end);

for k=1:1:max(size(data))
    file=horzcat('DATA/',data(k).name);
    [id,kom]=fopen(file);
    if id<0
         disp(kom)
     end
     MyData.(horzcat(data(k).name(1:end-4)))=fscanf(id, '%f %f',[3 4]);
end

createfigure(MyData.RRS, MyData.RRK)
xlabel('W')                                                      
ylabel('V') 
zlabel('RMSE DO ') 

createfigure(MyData.RBS, MyData.RBK)
xlabel('W')                                                      
ylabel('V') 
zlabel('RMSE BOD ') 
 
createfigure(MyData.MRS, MyData.MRK)
xlabel('W')                                                      
ylabel('V') 
zlabel('MAE DO ') 

createfigure(MyData.MBS, MyData.MBK)
xlabel('W')                                                      
ylabel('V') 
zlabel('MAE BOD ')