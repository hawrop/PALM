%  Gauss - stochastic noise generator

function xwyg=gauss(odc,wao)
p12n=sqrt(12.0/8.0);
p3n=sqrt(24.0);
sum=0.0;

for i=1:8,
 xwe=rand;
 sum=sum+xwe;
end

x=sum*p12n-p3n;
xwyg=odc*x+wao;
