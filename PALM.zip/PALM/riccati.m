% Gain coefficient calculation for Kalman filter

function [KFr]=riccati(A,C,V,D,W)

P_11=1;%4;%0.5;%5;%1;
P_12=-3.5;%-9;%-1.5;%-7.5;%-3.5;
P_21=-3.5;%-9;%-1.5;%-7.5;%-3.5;
P_22=2.5;%3;%1;%2.5;
P3S=[P_11,P_12;P_21,P_22];
P(1,1,1)=P_11;
P(1,2,1)=P_12;
P(2,1,1)=P_21;
P(2,2,1)=P_22;

% discretization step and calculation time for the Riccati equation

dt=0.01;% [doba]
T=20; 
n=T/dt;

for i=1:n
   Ps=A*P(:,:,i)+P(:,:,i)*A'-P(:,:,i)*C'*(V^(-1))*C*P(:,:,i)+D*W*D';
   P(:,:,i+1)=P(:,:,i)+dt*Ps;
   Pr11(i)=P(1,1,i);
   Pr12(i)=P(1,2,i);
   Pr22(i)=P(2,2,i);
   
end
 figure
 plot(0:dt:dt*(n-1),Pr11,'r')
  
 title('Changes over time in the covariance matrix of the estimation error P')
 xlabel('time [day]')
 ylabel('Elements of the matrix - P')
 hold on
 
 plot(0:dt:dt*(n-1),Pr12,'g')
 plot(0:dt:dt*(n-1),Pr22,'b')
 legend('P_(_1_,_1_)','P_(_1_,_2_)','P_(_2_,_2_)')
 grid

%%%%%%%%%% Filter gain from the Riccati equation

 Pu=P(:,:,n); % Covariance matrix of steady-state estimation error
 KFr=Pu*C'*(V^(-1));

%%%%