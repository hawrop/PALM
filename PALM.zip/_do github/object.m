%  Mathematical model of the object and measurements (tri-section river)

function [x1,y1,n]=object(WP,dt,W1,V1,A,D,C)

T=12; % observation period of one section of the river [day]
n1=T/dt; % first section
n2=n1; % second section
n3=n1; % third section
n=n1+n2+n3;

% initial values of the sections
WP1=[WP(1,1);WP(2,1)]; 
WP2=[WP(3,1);WP(4,1)];
WP3=[WP(5,1);WP(6,1)];

% first section
x1(:,1)=WP1;

data_x1 = zeros(size(x1, 1), n+1);  
data_y1 = zeros(1, n);              


 for i=1:n1
      w1=gauss(sqrt(W1(1,1)),0);
      w2=gauss(sqrt(W1(2,2)),0);
      w=[w1;w2];    
     if  w1<0
         w1=0;
     end
     if  w2<0
         w2=0;
     end
 
         x1(:,i+1)=x1(:,i)+ dt*(A*x1(:,i)+D*w); % object signals
         Vo=gauss(sqrt(V1),0);
          y1(i)=C*x1(:,i)+Vo; % measurement signal from the object          
   
    data_x1(:, i) = x1(:, i);
    data_y1(i) = y1(i);
 end

% second section
x1(:,n1)=WP2;

 for i=n1:n1+n2
      w1=gauss(sqrt(W1(1,1)),0);
      w2=gauss(sqrt(W1(2,2)),0);
      w=[w1;w2];    
     if  w1<0
         w1=0;
     end
     if  w2<0
         w2=0;
     end
 
         x1(:,i+1)=x1(:,i)+ dt*(A*x1(:,i)+D*w);
         Vo=gauss(sqrt(V1),0);
          y1(i)=C*x1(:,i)+Vo;
    
    data_x1(:, i) = x1(:, i);
    data_y1(i) = y1(i);
 end

% third section
x1(:,n1+n2)=WP3;

for i=n1+n2:n
      w1=gauss(sqrt(W1(1,1)),0);
      w2=gauss(sqrt(W1(2,2)),0);
      w=[w1;w2];    
     if  w1<0
         w1=0;
     end
     if  w2<0
         w2=0;
     end
 
         x1(:,i+1)=x1(:,i)+ dt*(A*x1(:,i)+D*w);
         Vo=gauss(sqrt(V1),0);
          y1(i)=C*x1(:,i)+Vo;
   
    data_x1(:, i) = x1(:, i);
    data_y1(i) = y1(i);
end

data_x1(:, end) = x1(:, end);
data_y1(end+1) = y1(end);

% Saving the simulation results to a object.csv file
writematrix([data_x1; data_y1], 'DATA/object.csv');

