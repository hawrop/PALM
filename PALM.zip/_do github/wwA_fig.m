% Chart of eigenvalues

% wwA - eigenvalues of the object
% wwAcl - eigenvalues of the KF
% wwAclaAw - eigenvalues of the PALM algorithm

function wwA_fig(wwA,wwAcl,wwAclaAw,n)

figure
hold on
plot(wwA(1,1),0,'o','LineWidth',2,'MarkerSize',10,'MarkerEdge','r')
plot(wwAcl(1,1),0,'d','LineWidth',2,'MarkerSize',10,'MarkerEdge','b')
plot(wwA(2,1),0,'o','LineWidth',2,'MarkerSize',10,'MarkerEdge','r')
plot(wwAcl(2,1),0,'d','LineWidth',2,'MarkerSize',10,'MarkerEdge','b')

for i=1:n

    if( imag(wwAclaAw)==0)
        plot(wwAclaAw(i,1),0,'x','LineWidth',1.5,'MarkerSize',10,'MarkerEdge','k')
    else
        plot(wwAclaAw,'x','LineWidth',1.5,'MarkerSize',10,'MarkerEdge','k')
        hold on
    end 
   %pause
end
grid
ylabel('Im \{^.\}')
xlabel('Re \{^.\} ')
if( imag(wwAcl)==0)
    legend('object','KFA','PALM')
else
    legend('object','','KFA','PALM')
     
end